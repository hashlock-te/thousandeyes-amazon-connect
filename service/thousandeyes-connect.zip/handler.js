'use strict';
const axios = require('axios').default;


module.exports.http = async (event) => {
  var message = "No Connection Info";
  var status = 200;
  var auth = {
    username: process.env.TE_USER,
    password: process.env.TE_TOKEN
  }

  // console.log(event);

  if (!event || !event.queryStringParameters || (!event.queryStringParameters.testId)) {
    message = "Missing 'testId' parameter.";
  } else if (!event || (!event.queryStringParameters.aid)) {
    message = "Missing 'aid' parameter.";
  } else {
    try {
      var response = await request (`https://api.thousandeyes.com/v6/endpoint-data/tests/web/http-server/${event.queryStringParameters.testId}.json`, event.queryStringParameters.aid, auth);
      status = response.status;      
      message = response.data.endpointWeb.httpServer[0];
    }
    catch {
    }
  }

  return slsResponse(status, message);
};

module.exports.network = async (event) => {
  var message = "No Connection Info";
  var status = 200;
  var auth = {
    username: process.env.TE_USER,
    password: process.env.TE_TOKEN
  }

  // console.log(event);

  if (!event || !event.queryStringParameters || (!event.queryStringParameters.testId)) {
    message = "Missing 'testId' parameter.";
  } else if (!event || (!event.queryStringParameters.aid)) {
    message = "Missing 'aid' parameter.";
  } else {
    try {
      var response = await request (`https://api.thousandeyes.com/v6/endpoint-data/tests/net/metrics/${event.queryStringParameters.testId}.json`, event.queryStringParameters.aid, auth);
      status = response.status;
      message = response.data.endpointNet.metrics[0];
    }
    catch {
    }
  }

  return slsResponse(status, message);
};

module.exports.agentinfo = async (event) => {
  var message = "No Connection Info";
  var status = 200;
  var auth = {
    username: process.env.TE_USER,
    password: process.env.TE_TOKEN
  }

  console.log(event);

  if (!event || !event.queryStringParameters || (!event.queryStringParameters.accountGroupName)
  || (!event.queryStringParameters.hostName)
  || (!event.queryStringParameters.testName)) {
    return slsResponse(status, "Missing accountGroup name, agentName, or testName.");
  } else {
  
    let agentInfo = {};
  
    try {
      var response = await request (`https://api.thousandeyes.com/v6/account-groups.json`, null, auth);
      if (response.data.accountGroups) {
        response.data.accountGroups.forEach(ag => {
          if (ag.accountGroupName == event.queryStringParameters.accountGroupName) {
            agentInfo.accountGroupId = ag.aid;
          }
        })
      } else {
        return slsResponse(status, "User does not belong to any account groups."); 
      };

      if (!agentInfo.accountGroupId) {
        message = `Could not find Account Group named ${event.queryStringParameters.accountGroupName}`;
        return slsResponse(status, message);
      }

      response = await request (`https://api.thousandeyes.com/v6/endpoint-tests.json`, agentInfo.accountGroupId, auth);
      
      if (response.data.endpointTest) {
        response.data.endpointTest.forEach(test => {
          if (test.testName == event.queryStringParameters.testName) {
            agentInfo.testId = test.testId;
          }
        })
      } 
      
      if (!agentInfo.testId) {
        return slsResponse(status, `Could not find endpoint test ${event.queryStringParameters.testName} in account group ${event.queryStringParameters.accountGroupName}.`); 
      }


      if (!event.queryStringParameters.hostName) {
        message = `Missing hostName parameter`; // ${event.queryStringParameters.accountGroupName}`;
        return slsResponse(status, message);
      }

      console.log(`https://api.thousandeyes.com/v6/endpoint-agents.json?computerName=${event.queryStringParameters.hostName}`);
      response = await request (`https://api.thousandeyes.com/v6/endpoint-agents.json?computerName=${event.queryStringParameters.hostName}`, agentInfo.accountGroupId, auth);
      
      console.log(response);

      if (response.data.endpointAgents && response.data.endpointAgents.length > 0) {
        agentInfo.agentId = response.data.endpointAgents[0].agentId;
      } 
      
      if (!agentInfo.agentId) {
        return slsResponse(status, `Could not find endpoint agent regisered for user device ${event.queryStringParameters.computerName}`); 
      }
      
      console.log(agentInfo);
      return slsResponse(response.status, agentInfo);
    }
    catch (e) {
      console.log(`Error: ${e}`)
    }

  }

  return slsResponse(status, message);
};

/*
{
  "message": {
    "ipAddress": "192.168.1.123",
    "subnetMask": "255.255.255.0",
    "publicIpAddress": "157.131.111.121",
    "localPrefix": "192.168.1.0",
    "publicIpRange": "157.131.64.0-157.131.127.255",
    "dnsServers": [
      "192.168.1.1"
    ],
    "gateway": "192.168.1.1",
    "type": "Ethernet",
    "hardwareType": "Wireless",
    "wirelessProfile": {
      "ssid": "teatime",
      "bssid": "fc:ec:da:e7:de:ea",
      "vendor": "Ubiquiti",
      "channel": 149,
      "phyMode": "802.11ac",
      "rssi": -47,
      "noise": -93,
      "quality": 100,
      "txRate": 300
    },
    "interfaceName": "en0"
  }
}
*/

module.exports.connection = async (event) => {
  var message = "No Connection Info";
  var status = 200;
  if (!event || !event.queryStringParameters || (!event.queryStringParameters.aid)
  || (!event.queryStringParameters.agentId)) {
    return slsResponse(status, "Missing aid or agentId.");
  } else {

    var reqBody = {
      searchFilters: [ {  key: 'agentId',  values: [`${event.queryStringParameters.agentId}`] } ]
    }
    var auth = {
      username: process.env.TE_USER,
      password: process.env.TE_TOKEN
    }

    try {
      var response = await request ('https://api.thousandeyes.com/v6/endpoint-data/network-topology.json?window=1h', event.queryStringParameters.aid, auth, 'post', reqBody,
      {
        window: '1h'
      });
      status = response.status;

      if (response.data.networkProbes.length > 0) {
        var networkProbeId = response.data.networkProbes[response.data.networkProbes.length - 1].networkProbeId;
        var resp2 = await request (`https://api.thousandeyes.com/v6/endpoint-data/network-topology/${networkProbeId}.json`, event.queryStringParameters.aid, auth);
        status = resp2.status;
        message = resp2.data.networkProbes[0].networkProfile;
      }
    } catch {
    }
}

  return slsResponse(status, message);
};

/*
POST https://api.thousandeyes.com/v6/endpoint-data/network-topology.json?window=1h
{
	"searchFilters": [
		{ 
			"key": "agentId", 
			"values": ["233de608-2c45-457f-b0ba-575d46c1a95e"]
		}
	]
}

JSONPath to get networkProbeIds:
$.networkProbes[*].networkProbeId
ex. 233de608-2c45-457f-b0ba-575d46c1a95e

// Get probe details
https://api.thousandeyes.com/v6/endpoint-data/network-topology/233de608-2c45-457f-b0ba-575d46c1a95e.json

  {
    "ipAddress": "192.168.1.123",
    "subnetMask": "255.255.255.0",
    "publicIpAddress": "157.131.111.121",
    "localPrefix": "192.168.1.0",
    "publicIpRange": "157.131.64.0-157.131.127.255",
    "dnsServers": [
      "192.168.1.1"
    ],
    "gateway": "192.168.1.1",
    "type": "Ethernet",
    "hardwareType": "Wireless",
    "wirelessProfile": {
      "ssid": "teatime",
      "bssid": "fc:ec:da:e7:de:ea",
      "vendor": "Ubiquiti",
      "channel": 149,
      "phyMode": "802.11ac",
      "rssi": -47,
      "noise": -93,
      "quality": 100,
      "txRate": 300
    },
    "interfaceName": "en0"
  }

*/
module.exports.status = async (event) => {
  return await query ('https://api.thousandeyes.com/v6/status/');
};

// async function query (urlPath, aid = null, _auth = null, _method='get', _body = null) {
//   let statusCode = 400;
//   let message = "Unknown Error";

//   try {
//     var opt = {
//       url: urlPath,
//       method: _method
//     }

//     if (aid) {
//       opt = {...opt, params: {aid: aid}}
//     }
//     if (_auth){
//       opt = {...opt, auth: _auth}
//     }
//     if (_body){
//      opt = {...opt, data: _body}
//     }

//     await axios(opt)
//     .then(function (response) {
//       statusCode = response.status;
//       message = response.data;
//     })
//     .catch(error => {
//       statusCode = 501;
//       message = `${error}`;
//     });
//   } catch (error) {
//       statusCode = 501;
//       message = `${error.message}`; // message 
//   }

//   return slsResponse(statusCode, message);
// }

async function request (urlPath, aid = null, _auth = null, _method='get', _body = null, _params = null) {
  try {
    var resp = {};

    var opt = {
      url: urlPath,
      method: _method
    }

    if (aid) {
      opt = {...opt, params: {aid: aid}}
    }
    if (_params){
      opt.params = {...opt.params, ..._params }
    }
    if (_auth){
      opt = {...opt, auth: _auth}
    }
    if (_body){
     opt = {...opt, data: _body}
    }

    // console.log (opt);

    await axios(opt)
    .then(function (response) {
      resp = {
        statusCode: response.status,
        data: response.data
      };
    })
    .catch(error => {
      return {
        statusCode: 501,
        data: `${error}`
      }
    });
  } catch (error) {
    return {
      statusCode: 501,
      data: `${error.message}`
    }
  }
  return resp;
}

function slsResponse (status, message) {
  return { 
    statusCode: status, 
    body: JSON.stringify( { message }, null, 2 ),
    headers: {
    // This is the only thing that get's cors to work. Serverless config doesn't
      'Access-Control-Allow-Origin': '*', // Required for CORS support to work
      'Access-Control-Allow-Credentials': true, // Required for cookies, authorization headers with HTTPS
    }
  }
}


// module.exports.hello = async (event, context) => {
//   try {
//     // do some real stuff but it throws an error, oh no!
//     throw new Error('new error')
//   } catch (error) {
//     context.captureError(error)
//   }
//   return {
//     statusCode: 400,
//     body: JSON.stringify({ error: 'my nice error message' }),
//   };
// };



// function makeRequest(url, method, headers, payload) {
//   var request = new XMLHttpRequest();
//   request.name = name;
//   return new Promise(function (resolve, reject) {
//     // Setup our listener to process compeleted requests
//     request.onreadystatechange = function () {
//       // Only run if the request is complete
//       if (request.readyState !== 4) return;
//       // Process the response
//       if (request.status >= 200 && request.status < 300) {
//         // If successful
//         try {
//           request.responseJSON = JSON.parse(request.responseText);
//         } catch { }
//         resolve(request);
//       } else {
//         // If failed
//         try {
//           request.responseJSON = JSON.parse(request.responseText);
//         } catch { }
//         reject(request);
//       }
//     };
//     request.open(method || "GET", url, true);
//     for (key in headers) {
//       request.setRequestHeader(key, headers[key]);
//     }
//     request.send(payload);
//   });
// }

// async function makeApiRequest(urlPath, method, aid, json) {
//   let url = "https://api.thousandeyes.com" + urlPath;
//   let apiCredentials = await storageGet(["apiCredentials"]);
//   let headers = {
//     Authorization:
//       "Basic " + btoa(apiCredentials.email + ":" + apiCredentials.token),
//     "Content-Type": "application/json",
//     Accept: "application/json",
//   };
//   if (aid !== undefined && aid > 0) {
//     let u = new URL(url);
//     u.searchParams.append("aid", aid);
//     url = u.href;
//   }
//   let payload = json;
//   if (typeof json != "string") {
//     payload = JSON.stringify(json);
//   }

//   return makeRequest(url, method, headers, payload).catch(async function (
//     rejectedRequest
//   ) {
//     if (rejectedRequest.status == 429) {
//       showRateWarning(true);
//       let te_date, d;
//       await getTEDate()
//         .then((time) => {
//           te_date = Math.round(time / 1000);
//         })
//         .catch((r) => {
//           d = Math.round(Date.now() / 1000);
//         });

//       let resetTime = rejectedRequest.getResponseHeader(
//         "X-Organization-Rate-Limit-Reset"
//       );
//       let resetSeconds = resetTime - (te_date || d) + 1;
//       console.log(
//         "API Rate limit reached. Retrying once in " + resetSeconds + " seconds."
//       );
//       await new Promise((r) => setTimeout(r, resetSeconds * 1000));
//       showRateWarning(false);
//       return makeRequest(url, method, headers, payload);
//     } else {
//       throw rejectedRequest;
//     }
//   });
// }
